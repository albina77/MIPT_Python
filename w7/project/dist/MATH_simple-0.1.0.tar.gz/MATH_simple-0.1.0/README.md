Hello everyone! It's my first package. I did it to make easy life about vectors and some math (sqrt, sin). 
Joke, it's for my homework (ha-ha, classic).
You should install math, cmath, numpy to use it