import setuptools

setuptools.setup(
    name="MATH_simple", # Replace with your own username
    version="0.1.0",
    author="albina_albina77",
    author_email="unbrella77@mail.ru",
    description="A small package of mathematics",
    long_description="long long",
    long_description_content_type="text/markdown",
    url="https://github.com/albina77/MIPT_Python",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)